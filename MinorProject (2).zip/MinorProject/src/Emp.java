public class Emp {
String empname,empid,email,psw,mobileno,post,empaddress;

public String getEmpname() {
	return empname;
}

public void setEmpname(String empname) {
	this.empname = empname;
}

public String getEmpid() {
	return empid;
}

public void setEmpid(String empid) {
	this.empid = empid;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPsw() {
	return psw;
}

public void setPsw(String psw) {
	this.psw = psw;
}

public String getMobileno() {
	return mobileno;
}

public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}

public String getPost() {
	return post;
}

public void setPost(String post) {
	this.post = post;
}

public String getEmpaddress() {
	return empaddress;
}

public void setEmpaddress(String empaddress) {
	this.empaddress = empaddress;
}

}
