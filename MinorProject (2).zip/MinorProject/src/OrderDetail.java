public class OrderDetail {
String ordid,orddetail,dilistatus,biliprice,discount,paymentstatus,paymentmode,data;

public String getOrdid() {
	return ordid;
}

public void setOrdid(String ordid) {
	this.ordid = ordid;
}

public String getOrddetail() {
	return orddetail;
}

public void setOrddetail(String orddetail) {
	this.orddetail = orddetail;
}

public String getDilistatus() {
	return dilistatus;
}

public void setDilistatus(String dilistatus) {
	this.dilistatus = dilistatus;
}

public String getBiliprice() {
	return biliprice;
}

public void setBiliprice(String biliprice) {
	this.biliprice = biliprice;
}

public String getDiscount() {
	return discount;
}

public void setDiscount(String discount) {
	this.discount = discount;
}

public String getPaymentstatus() {
	return paymentstatus;
}

public void setPaymentstatus(String paymentstatus) {
	this.paymentstatus = paymentstatus;
}

public String getPaymentmode() {
	return paymentmode;
}

public void setPaymentmode(String paymentmode) {
	this.paymentmode = paymentmode;
}

public String getData() {
	return data;
}

public void setData(String data) {
	this.data = data;
}

}
